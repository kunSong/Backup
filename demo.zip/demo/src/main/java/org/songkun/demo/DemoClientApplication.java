package org.songkun.demo;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class DemoClientApplication {

    public static void main(String[] args) {
//        try {
//            DemoApplication.UDPClient();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

//        try {
//            DemoApplication.rmiClient();
//        } catch (RemoteException e) {
//            e.printStackTrace();
//        } catch (NotBoundException e) {
//            e.printStackTrace();
//        }
    }
}
